import { createClient } from "npm:@supabase/supabase-js@2";

const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
const jwtSecret = Deno.env.get("SUPABASE_JWT_SECRET") ?? "";
const emailJsServiceId = Deno.env.get("EMAILJS_SERVICE_ID") ?? "";
const emailJsTemplateId = Deno.env.get("EMAILJS_TEMPLATE_ID") ?? "";
const emailJsPublicKey = Deno.env.get("EMAILJS_PUBLIC_KEY") ?? "";
const allowedOrigins = (Deno.env.get("APP_ORIGINS") ?? "")
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);
const expectedAdminEmail = "morakeyran89@gmail.com".trim().toLowerCase();
const serviceClient = supabaseUrl && serviceRoleKey
  ? createClient(supabaseUrl, serviceRoleKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  })
  : null;

function corsHeaders(origin: string | null): Record<string, string> {
  const headers: Record<string, string> = {
    "Access-Control-Allow-Headers": "apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Vary": "Origin",
  };
  if (origin && allowedOrigins.includes(origin)) {
    headers["Access-Control-Allow-Origin"] = origin;
  }
  return headers;
}

function jsonResponse(
  body: Record<string, unknown>,
  status: number,
  origin: string | null,
): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders(origin), "Content-Type": "application/json" },
  });
}

function encodeBase64Url(bytes: Uint8Array): string {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}

async function signAdminToken(admin: { id: string; usuario: string }) {
  if (!jwtSecret) throw new Error("Missing JWT signing secret.");
  const issuedAt = Math.floor(Date.now() / 1000);
  const expiresAt = issuedAt + 15 * 60;
  const header = encodeBase64Url(
    new TextEncoder().encode(JSON.stringify({ alg: "HS256", typ: "JWT" })),
  );
  const payload = encodeBase64Url(
    new TextEncoder().encode(JSON.stringify({
      aud: "authenticated",
      app_metadata: { role: "admin", usuario: admin.usuario },
      exp: expiresAt,
      iat: issuedAt,
      iss: `${supabaseUrl}/auth/v1`,
      role: "authenticated",
      sub: admin.id,
    })),
  );
  const content = `${header}.${payload}`;
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(jwtSecret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const signature = new Uint8Array(
    await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(content)),
  );
  return { accessToken: `${content}.${encodeBase64Url(signature)}`, expiresAt };
}

async function hashRateLimitKey(action: string, ip: string) {
  const input = new TextEncoder().encode(`${action}\n${ip}`);
  const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", input));
  return Array.from(digest, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

function requestIp(request: Request) {
  const forwarded = request.headers.get("x-forwarded-for");
  if (forwarded) return forwarded.split(",").map((part) => part.trim()).filter(Boolean).at(-1) ?? "unknown";
  return request.headers.get("x-real-ip") ?? "unknown";
}

async function allowRequest(
  action: "start" | "verify" | "track",
  ip: string,
  limit: number,
) {
  if (!serviceClient) throw new Error("Authentication service is unavailable.");
  const keyHash = await hashRateLimitKey(action, ip);
  const { data, error } = await serviceClient.rpc("consume_admin_auth_rate_limit", {
    p_action: action,
    p_key_hash: keyHash,
    p_limit: limit,
    p_window_seconds: 900,
  });
  if (error || typeof data !== "boolean") {
    console.error("Rate limiter request failed:", error?.message ?? "Invalid response.");
    throw new Error("Authentication service is unavailable.");
  }
  return data;
}

function generateSixDigitCode(): string {
  const range = 0x1_0000_0000;
  const limit = Math.floor(range / 1_000_000) * 1_000_000;
  const bytes = new Uint32Array(1);
  do {
    crypto.getRandomValues(bytes);
  } while (bytes[0] >= limit);
  return String(bytes[0] % 1_000_000).padStart(6, "0");
}

async function sendVerificationEmail(email: string, code: string) {
  if (!emailJsServiceId || !emailJsTemplateId || !emailJsPublicKey) {
    throw new Error("Email delivery is not configured.");
  }
  const response = await fetch("https://api.emailjs.com/api/v1.0/email/send", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      service_id: emailJsServiceId,
      template_id: emailJsTemplateId,
      user_id: emailJsPublicKey,
      template_params: {
        codigo: code,
        email,
        to_email: email,
      },
    }),
  });
  if (!response.ok) {
    const details = await response.text();
    console.error("EmailJS rejected the verification email:", response.status, details.slice(0, 500));
    throw new Error("Email delivery failed.");
  }
}

async function startAuthentication(
  requestedEmail: string,
  ip: string,
  origin: string | null,
) {
  if (!serviceClient || !jwtSecret) {
    console.error("Admin authentication secrets are not configured.");
    return jsonResponse({ error: "Authentication service is unavailable." }, 503, origin);
  }
  if (!await allowRequest("start", ip, 5)) {
    return jsonResponse({ error: "Too many attempts. Try again later." }, 429, origin);
  }
  const email = requestedEmail.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return jsonResponse({ error: "Invalid email address." }, 400, origin);
  }
  const { data: administrators, error } = await serviceClient
    .from("administradores")
    .select("id, usuario, gmail");
  if (error) {
    console.error("Could not retrieve administrator record:", error.message);
    return jsonResponse({ error: "Authentication service is unavailable." }, 503, origin);
  }
  const matchingAdmins = administrators.filter((administrator) =>
    String(administrator.gmail ?? "").trim().toLowerCase() === email &&
    email === expectedAdminEmail
  );
  if (matchingAdmins.length !== 1) {
    return jsonResponse({ sent: true }, 200, origin);
  }
  const admin = matchingAdmins[0];
  const code = generateSixDigitCode();
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();
  const { error: updateError } = await serviceClient
    .from("administradores")
    .update({ codigo_2fa: code, expiracion_2fa: expiresAt })
    .eq("id", admin.id);
  if (updateError) {
    console.error("Could not save administrator verification code:", updateError.message);
    return jsonResponse({ error: "Authentication service is unavailable." }, 503, origin);
  }
  try {
    await sendVerificationEmail(email, code);
  } catch (error) {
    console.error("Could not send administrator verification code:", error);
    const { error: clearError } = await serviceClient
      .from("administradores")
      .update({ codigo_2fa: null, expiracion_2fa: null })
      .eq("id", admin.id)
      .eq("codigo_2fa", code);
    if (clearError) console.error("Could not clear unsent verification code:", clearError.message);
    return jsonResponse({ error: "Verification email could not be sent." }, 503, origin);
  }
  return jsonResponse({ sent: true }, 200, origin);
}

async function verifyAuthentication(
  requestedEmail: string,
  code: string,
  ip: string,
  origin: string | null,
) {
  if (!serviceClient || !jwtSecret) {
    return jsonResponse({ error: "Authentication service is unavailable." }, 503, origin);
  }
  if (!await allowRequest("verify", ip, 8)) {
    return jsonResponse({ error: "Too many attempts. Request a new code later." }, 429, origin);
  }
  if (!/^\d{6}$/.test(code)) {
    return jsonResponse({ error: "Invalid or expired code." }, 401, origin);
  }
  const email = requestedEmail.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email !== expectedAdminEmail) {
    return jsonResponse({ error: "Invalid or expired code." }, 401, origin);
  }
  const now = new Date().toISOString();
  const { data: matchingAdmins, error } = await serviceClient
    .from("administradores")
    .select("id, usuario, gmail")
    .eq("codigo_2fa", code)
    .gt("expiracion_2fa", now);
  if (error) {
    console.error("Could not verify administrator code:", error.message);
    return jsonResponse({ error: "Authentication service is unavailable." }, 503, origin);
  }
  const matchingAdmin = matchingAdmins.find((administrator) =>
    String(administrator.gmail ?? "").trim().toLowerCase() === email
  );
  const admin = matchingAdmin;
  if (!admin) {
    return jsonResponse({ error: "Invalid or expired code." }, 401, origin);
  }
  const { data: consumed, error: consumeError } = await serviceClient
    .from("administradores")
    .update({ codigo_2fa: null, expiracion_2fa: null })
    .eq("id", admin.id)
    .eq("codigo_2fa", code)
    .gt("expiracion_2fa", now)
    .select("id")
    .maybeSingle();
  if (consumeError) {
    console.error("Could not consume administrator code:", consumeError.message);
    return jsonResponse({ error: "Authentication service is unavailable." }, 503, origin);
  }
  if (!consumed) {
    return jsonResponse({ error: "Invalid or expired code." }, 401, origin);
  }

  try {
    const { accessToken, expiresAt } = await signAdminToken(admin);
    return jsonResponse({
      access_token: accessToken,
      expires_at: expiresAt * 1000,
    }, 200, origin);
  } catch (error) {
    console.error("Could not issue administrator access token:", error);
    return jsonResponse({ error: "Authentication service is unavailable." }, 503, origin);
  }
}

async function trackAppointment(code: string, ip: string, origin: string | null) {
  if (!serviceClient) {
    return jsonResponse({ error: "Tracking service is unavailable." }, 503, origin);
  }
  if (!await allowRequest("track", ip, 20)) {
    return jsonResponse({ error: "Too many requests. Try again later." }, 429, origin);
  }
  if (!/^CONS-[2-9A-HJ-NP-Z]{5}$/.test(code)) {
    return jsonResponse({ appointment: null }, 200, origin);
  }
  const { data, error } = await serviceClient
    .from("citas")
    .select("nombre_cliente, servicio, fecha_cita, hora_cita, estado")
    .eq("codigo_seguimiento", code)
    .maybeSingle();
  if (error) {
    console.error("Could not look up appointment tracking code:", error.message);
    return jsonResponse({ error: "Tracking service is unavailable." }, 503, origin);
  }
  return jsonResponse({ appointment: data }, 200, origin);
}

Deno.serve(async (request: Request) => {
  const origin = request.headers.get("origin");
  if (origin && !allowedOrigins.includes(origin)) {
    return jsonResponse({ error: "Origin is not allowed." }, 403, null);
  }
  if (request.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders(origin) });
  }
  if (request.method !== "POST") {
    return jsonResponse({ error: "Method not allowed." }, 405, origin);
  }
  const contentLength = Number(request.headers.get("content-length") || 0);
  if (contentLength > 4096) {
    return jsonResponse({ error: "Request is too large." }, 413, origin);
  }
  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return jsonResponse({ error: "Invalid request." }, 400, origin);
  }

  const action = body.action;
  const ip = requestIp(request);
  try {
    if (action === "start") {
      const email = typeof body.email === "string" ? body.email : "";
      if (!email || email.length > 254) {
        return jsonResponse({ error: "Invalid email address." }, 400, origin);
      }
      return await startAuthentication(email, ip, origin);
    }
    if (action === "verify") {
      const email = typeof body.email === "string" ? body.email : "";
      const code = typeof body.codigo === "string" ? body.codigo.trim() : "";
      if (!email || email.length > 254) {
        return jsonResponse({ error: "Invalid or expired code." }, 401, origin);
      }
      return await verifyAuthentication(email, code, ip, origin);
    }
    if (action === "track") {
      const code = typeof body.code === "string" ? body.code.trim().toUpperCase() : "";
      return await trackAppointment(code, ip, origin);
    }
    return jsonResponse({ error: "Invalid request." }, 400, origin);
  } catch (error) {
    console.error("Unexpected authentication service failure:", error);
    return jsonResponse({ error: "Authentication service is unavailable." }, 503, origin);
  }
});
