create extension if not exists pgcrypto with schema extensions;

alter table public.administradores
  add column if not exists id uuid default gen_random_uuid(),
  add column if not exists codigo_2fa text,
  add column if not exists expiracion_2fa timestamptz;

update public.administradores
set id = gen_random_uuid()
where id is null;

alter table public.administradores
  alter column id set not null;

alter table public.administradores
  alter column clave type text using clave::text;

create unique index if not exists administradores_id_key
  on public.administradores (id);

create unique index if not exists administradores_usuario_lower_key
  on public.administradores (lower(usuario));

update public.administradores
set clave = extensions.crypt(clave, extensions.gen_salt('bf', 12))
where clave !~ '^\$2[aby]\$';

alter table public.administradores enable row level security;
revoke all on public.administradores from public, anon, authenticated;
grant all on public.administradores to service_role;

create table if not exists public.admin_auth_rate_limits (
  accion text not null,
  clave_hash text not null,
  ventana_inicio timestamptz not null,
  solicitudes integer not null default 0,
  primary key (accion, clave_hash, ventana_inicio)
);

alter table public.admin_auth_rate_limits enable row level security;
revoke all on public.admin_auth_rate_limits from public, anon, authenticated;
grant all on public.admin_auth_rate_limits to service_role;

create or replace function public.consume_admin_auth_rate_limit(
  p_action text,
  p_key_hash text,
  p_limit integer,
  p_window_seconds integer
)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_window_start timestamptz;
  v_count integer;
begin
  if p_action not in ('start', 'verify', 'track')
     or p_limit < 1
     or p_window_seconds < 1
     or length(p_key_hash) <> 64 then
    raise exception 'Invalid rate limit parameters';
  end if;

  v_window_start := to_timestamp(
    floor(extract(epoch from now()) / p_window_seconds) * p_window_seconds
  );

  insert into public.admin_auth_rate_limits as current_limit (
    accion, clave_hash, ventana_inicio, solicitudes
  )
  values (p_action, p_key_hash, v_window_start, 1)
  on conflict (accion, clave_hash, ventana_inicio)
  do update set solicitudes = current_limit.solicitudes + 1
  returning solicitudes into v_count;

  if random() < 0.01 then
    delete from public.admin_auth_rate_limits
    where ventana_inicio < now() - interval '1 day';
  end if;

  return v_count <= p_limit;
end;
$$;

revoke all on function public.consume_admin_auth_rate_limit(text, text, integer, integer)
  from public, anon, authenticated;
grant execute on function public.consume_admin_auth_rate_limit(text, text, integer, integer)
  to service_role;

alter table public.citas enable row level security;
alter table public.proyectos_solicitados enable row level security;
alter table public.charlas enable row level security;
alter table public.inscripciones_charlas enable row level security;
alter table public.entradas enable row level security;

revoke all on public.citas, public.proyectos_solicitados, public.charlas,
  public.inscripciones_charlas, public.entradas
  from public, anon, authenticated;

grant insert on public.citas, public.proyectos_solicitados, public.inscripciones_charlas to anon;
grant select on public.charlas to anon;
grant select, insert, update, delete on public.citas, public.proyectos_solicitados,
  public.charlas, public.inscripciones_charlas, public.entradas to authenticated;

grant usage, select on all sequences in schema public to authenticated;

do $$
declare
  table_name text;
  sequence_name text;
begin
  foreach table_name in array array['citas', 'proyectos_solicitados', 'inscripciones_charlas']
  loop
    sequence_name := pg_get_serial_sequence(format('public.%I', table_name), 'id');
    if sequence_name is not null then
      execute format('grant usage, select on sequence %s to anon', sequence_name);
    end if;
  end loop;
end;
$$;

do $$
declare
  existing_policy record;
begin
  for existing_policy in
    select policyname, tablename
    from pg_policies
    where schemaname = 'public'
      and tablename in (
        'citas',
        'proyectos_solicitados',
        'charlas',
        'inscripciones_charlas',
        'entradas'
      )
  loop
    execute format(
      'drop policy %I on public.%I',
      existing_policy.policyname,
      existing_policy.tablename
    );
  end loop;
end;
$$;

drop policy if exists "Public can create appointments" on public.citas;
create policy "Public can create appointments"
  on public.citas for insert to anon
  with check (coalesce(estado, 'Pendiente') = 'Pendiente');

drop policy if exists "Admins manage appointments" on public.citas;
create policy "Admins manage appointments"
  on public.citas for all to authenticated
  using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
  with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

drop policy if exists "Public can submit project requests" on public.proyectos_solicitados;
create policy "Public can submit project requests"
  on public.proyectos_solicitados for insert to anon
  with check (coalesce(estado, 'Nuevo') = 'Nuevo');

drop policy if exists "Admins manage project requests" on public.proyectos_solicitados;
create policy "Admins manage project requests"
  on public.proyectos_solicitados for all to authenticated
  using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
  with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

drop policy if exists "Public can view active events" on public.charlas;
create policy "Public can view active events"
  on public.charlas for select to anon
  using (activa = true);

drop policy if exists "Admins manage events" on public.charlas;
create policy "Admins manage events"
  on public.charlas for all to authenticated
  using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
  with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

drop policy if exists "Public can register for events" on public.inscripciones_charlas;
create policy "Public can register for events"
  on public.inscripciones_charlas for insert to anon
  with check (
    exists (
      select 1
      from public.charlas as event
      where event.id = charla_id
        and event.activa = true
        and event.fecha_evento >= current_date
    )
  );

drop policy if exists "Admins manage event registrations" on public.inscripciones_charlas;
create policy "Admins manage event registrations"
  on public.inscripciones_charlas for all to authenticated
  using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
  with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

drop policy if exists "Admins manage articles" on public.entradas;
create policy "Admins manage articles"
  on public.entradas for all to authenticated
  using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
  with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

create or replace function public.get_public_event_registration_counts()
returns table (charla_id bigint, registration_count bigint)
language sql
security definer
set search_path = ''
as $$
  select registration.charla_id, count(*)::bigint
  from public.inscripciones_charlas as registration
  join public.charlas as event on event.id = registration.charla_id
  where event.activa = true
    and event.fecha_evento >= current_date
  group by registration.charla_id;
$$;

revoke all on function public.get_public_event_registration_counts() from public, anon, authenticated;
grant execute on function public.get_public_event_registration_counts() to anon, authenticated;

create or replace function public.get_public_articles()
returns table (
  id bigint,
  created_at timestamptz,
  titulo text,
  categoria text,
  autor text,
  contenido text,
  publicado boolean,
  tipo_acceso text,
  url_imagen text
)
language sql
security definer
set search_path = ''
as $$
  select
    article.id,
    article.created_at,
    article.titulo,
    article.categoria,
    article.autor,
    case when coalesce(article.tipo_acceso, 'Público') = 'Público'
      then article.contenido
      else null::text
    end,
    article.publicado,
    coalesce(article.tipo_acceso, 'Público'),
    article.url_imagen
  from public.entradas as article
  where article.publicado = true
  order by article.created_at desc;
$$;

revoke all on function public.get_public_articles() from public, anon, authenticated;
grant execute on function public.get_public_articles() to anon, authenticated;
