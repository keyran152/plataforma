# Administrator email-code authentication

The static site cannot enforce admin-only database access on its own. The `admin-auth` Edge Function checks the submitted email against the normalized `gmail` column in `public.administradores`, sends and consumes the one-time code, and issues a short-lived admin JWT. Admin database requests use that token in memory; it is not written to browser storage.

Email-only codes are a **single-factor, passwordless** login method, not two-factor authentication. Anyone who controls the registered mailbox can request and use a code. Keep the existing per-IP rate limits, secure the mailbox with MFA, and restore an independent password or stronger identity provider before treating this as production authentication.

## One-time setup

1. Confirm `public.administradores` contains exactly one row whose `gmail` value normalizes to `morakeyran89@gmail.com`. The function applies `trim().toLowerCase()` to the submitted and stored email values, and will not send codes for other addresses. The migration adds an internal UUID and currently hashes any legacy plaintext `clave`; that column is not used by the email-code login.
2. Apply the migration:

   ```powershell
   supabase db push
   ```

   It enables RLS, replaces existing policies on `citas`, `proyectos_solicitados`, `charlas`, `inscripciones_charlas`, and `entradas`, and grants public access only to the operations used by the public portal. Public event counts and blog cards use restricted RPCs; anonymous clients cannot read attendee records, appointments, or exclusive article content. Review any custom policies on those tables before applying.
3. Configure Edge Function secrets in the Supabase project. Obtain the JWT signing secret from the project API settings; never put it in this repository or frontend.

   ```powershell
   supabase secrets set SUPABASE_JWT_SECRET="<project JWT signing secret>"
   supabase secrets set EMAILJS_SERVICE_ID="<EmailJS service ID>" EMAILJS_TEMPLATE_ID="<EmailJS template ID>" EMAILJS_PUBLIC_KEY="<EmailJS public key>"
   supabase secrets set APP_ORIGINS="http://127.0.0.1:8765,http://localhost:8765,https://your-production-domain.example"
   ```

   Supabase provides `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` to Edge Functions. Verify they are available in the function environment. `APP_ORIGINS` must contain the exact origins used by local development and production; remove origins that are not in use.
4. Configure the EmailJS template's recipient as `{{to_email}}` and include `{{codigo}}` in the email body. The function always sends to the configured administrator email; it does not accept a recipient from the browser.
5. Deploy the function:

   ```powershell
   supabase functions deploy admin-auth --no-verify-jwt
   ```

   The function intentionally has gateway JWT verification disabled so the public site can request an email code. It rate-limits requests, rejects unapproved browser origins, does not disclose whether an email is registered, and returns an admin JWT only after one-time-code verification. The database migration ensures that the public key alone cannot read or modify admin records.

## Operational notes

- The one-time code expires after five minutes and is consumed atomically. Admin JWTs expire after 15 minutes; the browser clears the session and hides the panel at expiry.
- EmailJS is called from the Edge Function over its HTTPS API rather than through the browser SDK, so the one-time code is never returned to the page.
- The signed admin JWT uses the project's legacy HS256 JWT signing secret. If the project uses asymmetric JWT signing keys or rotates the signing secret, this implementation must be updated to match the active signing configuration before deployment.
- Apply and test the migration and function in a non-production Supabase project first. Public appointment status lookup is also routed through the Edge Function because anonymous table reads are revoked.
